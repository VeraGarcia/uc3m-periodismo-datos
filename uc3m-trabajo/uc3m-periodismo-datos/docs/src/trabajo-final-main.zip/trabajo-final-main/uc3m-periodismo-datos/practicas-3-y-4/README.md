# practicas-3-y-4
Prácticas 3 y 4 de la asignatura, realizadas mediante la utilización de OpenRefine para filtrar los resultados a partir de una base de datos en formato .csv y la posterior representación de los mismos por medio de Datawrapper. 
